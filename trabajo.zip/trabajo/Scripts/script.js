// Se carga la lista de registros desde localStorage
const registros = JSON.parse(localStorage.getItem("registros")) || [];

// Se carga el inventario existente para conservar los productos entre visitas.
const productos = JSON.parse(localStorage.getItem("productos")) || [];

// Se carga el historial de ventas para guardar cada compra realizada por un cliente.
const ventas = JSON.parse(localStorage.getItem("ventas")) || [];

// Se obtiene el usuario activo para comprobar sus permisos antes de mostrar el formulario.
const usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));
// Se busca el formulario de productos; en otras páginas este elemento no existe y no se aplica la regla.
const formularioProducto = document.getElementById("formulario-product");

// Se bloquea el acceso si no hay sesión o si el usuario activo no tiene el rol admin.
if (formularioProducto && (!usuarioActual || usuarioActual.usuario !== "admin")) {
    // Se informa al usuario por qué no puede acceder al formulario.
    alert("No tienes permisos para registrar productos.");
    // Se devuelve al usuario al panel principal después de rechazar el acceso.
    window.location.href = "home.html";
}

// Se obtiene el formulario de productos para conectar sus datos con el inventario.
const formularioProductoRegistro = document.getElementById("formulario-product");

if (formularioProductoRegistro && usuarioActual && usuarioActual.usuario === "admin") {
    // Se guarda cada producto después de validar sus datos básicos.
    formularioProductoRegistro.addEventListener("submit", function(evento) {
        evento.preventDefault();

        // Se leen y limpian los valores escritos por el administrador.
        const id = document.getElementById("idProducto").value.trim();
        const nombre = document.getElementById("nombreProducto").value.trim();
        const descripcion = document.getElementById("descripcionprodcuto").value.trim();
        const stock = Number(document.getElementById("stockproducto").value);
        const precio = Number(document.getElementById("precio").value);

        // Se impide guardar campos vacíos, cantidades negativas o precios inválidos.
        if (!id || !nombre || !descripcion || !Number.isInteger(stock) || stock < 0 || !Number.isFinite(precio) || precio < 0) {
            alert("Complete todos los campos con valores válidos.");
            return;
        }

        // Se evita que dos productos tengan el mismo identificador.
        if (productos.some(function(producto) { return producto.id === id; })) {
            alert("Ya existe un producto con ese ID.");
            return;
        }

        // Se agrega el producto y se actualiza el inventario guardado.
        productos.push({ id, nombre, descripcion, stock, precio });
        localStorage.setItem("productos", JSON.stringify(productos));
        alert("Producto registrado correctamente.");
        formularioProductoRegistro.reset();
    });
}

// Se obtiene el formulario de ventas para permitir compras solamente a clientes.
const formularioVenta = document.getElementById("formulario-venta");
const selectorProductoVenta = document.getElementById("productoVenta");
const mensajeVenta = document.getElementById("mensajeVenta");

if (formularioVenta && (!usuarioActual || usuarioActual.usuario !== "cliente")) {
    // Se informa que los administradores no tienen permiso para comprar productos.
    alert("Solo los clientes pueden comprar productos.");
    // Se redirige al panel para evitar el uso directo de la página de ventas.
    window.location.href = "home.html";
}

if (formularioVenta && usuarioActual && usuarioActual.usuario === "cliente") {
    // Se muestran únicamente productos con unidades disponibles para la venta.
    function cargarProductosDisponibles() {
        selectorProductoVenta.innerHTML = "";
        const productosDisponibles = productos.filter(function(producto) {
            return producto.stock > 0;
        });

        // Se informa al cliente cuando todavía no hay productos disponibles.
        if (productosDisponibles.length === 0) {
            const opcionVacia = document.createElement("option");
            opcionVacia.textContent = "No hay productos disponibles";
            opcionVacia.value = "";
            selectorProductoVenta.appendChild(opcionVacia);
            formularioVenta.querySelector("button[type='submit']").disabled = true;
            if (mensajeVenta) mensajeVenta.textContent = "No hay productos con stock disponible.";
            return;
        }

        // Se crea una opción con nombre, precio y stock para cada producto disponible.
        productosDisponibles.forEach(function(producto) {
            const opcion = document.createElement("option");
            opcion.value = producto.id;
            opcion.textContent = producto.nombre + " - $" + producto.precio + " (Stock: " + producto.stock + ")";
            selectorProductoVenta.appendChild(opcion);
        });
        formularioVenta.querySelector("button[type='submit']").disabled = false;
    }

    // Se carga el selector al abrir la página de ventas.
    cargarProductosDisponibles();

    // Se procesa la compra y se actualizan inventario e historial de ventas.
    formularioVenta.addEventListener("submit", function(evento) {
        evento.preventDefault();

        // Se vuelve a leer el inventario para validar el stock más reciente.
        const inventarioActual = JSON.parse(localStorage.getItem("productos")) || [];
        const idProducto = selectorProductoVenta.value;
        const cantidad = Number(document.getElementById("cantidadVenta").value);
        const producto = inventarioActual.find(function(elemento) {
            return elemento.id === idProducto;
        });

        // Se impide comprar cantidades inválidas o superiores al stock real.
        if (!producto || !Number.isInteger(cantidad) || cantidad < 1) {
            alert("Seleccione un producto y una cantidad válida.");
            return;
        }
        if (cantidad > producto.stock) {
            alert("La cantidad solicitada supera el stock disponible.");
            return;
        }

        // Se descuentan las unidades compradas del producto seleccionado.
        producto.stock -= cantidad;
        localStorage.setItem("productos", JSON.stringify(inventarioActual));

        // Se guarda el detalle necesario para mostrar la compra en el perfil del cliente.
        ventas.push({
            idProducto: producto.id,
            nombreProducto: producto.nombre,
            cantidad: cantidad,
            precioUnitario: producto.precio,
            total: producto.precio * cantidad,
            fecha: new Date().toLocaleString(),
            cedulaCliente: usuarioActual.cedula
        });
        localStorage.setItem("ventas", JSON.stringify(ventas));

        // Se actualiza la lista para ocultar el producto si se agotó.
        alert("Compra realizada correctamente.");
        document.getElementById("cantidadVenta").value = "1";
        cargarProductosDisponibles();
    });
}

// Se crea una referencia segura al contenedor donde se muestran los usuarios
const resultado = document.getElementById("resultado");

function mostrarRegistros() {
    // Se valida antes de intentar usar el contenedor de resultados
    if (!resultado) return;

    //Se limpia el contenido del contenedor antes de volver a dibujar la lista
    //de esta forma no se duplican los registros cada vez que se ejecuta la función
    resultado.innerHTML = "";

    // Se crea la lista con elementos HTML para mostrar cada registro
    let lista = document.createElement("ol");

    // [Cambio 6] Se recorre cada usuario guardado y se genera un item HTML por cada uno
    // esto permite mostrar cedula, nombre, email, contraseña y fecha 
    registros.forEach(function(registro) {
        let item = document.createElement("li");
        item.innerHTML = `
        <strong>cedula:</strong> ${registro.cedula} <br>
        <strong>nombre:</strong> ${registro.nombre} <br>
        <strong>email:</strong> ${registro.email} <br>
        <strong>contrasena:</strong> ${registro.contrasena} <br>
        <strong>fecha:</strong> ${registro.fecha} <br>
        <strong>tipoUsuario:</strong> ${registro.tipoUsuario} <br>
        `;
        lista.appendChild(item);
    }); 
    // Solo se agrega la lista si hay registros guardados
    // evita mostrar una lista vacía en páginas donde todavía no existe información
    if (registros.length > 0) {
        resultado.appendChild(lista);
    }
}

    // Se verifica si el formulario de registro existe antes de asignar el evento submit
const formulario = document.getElementById("formulario");

if (formulario) {
    // [Cambio 9] Se captura el evento submit del formulario de registro
    // para permitir guardar los datos ingresados por el usuario al hacer clic en Registrar
    formulario.addEventListener("submit", function(e) {
        e.preventDefault();

        // Se leen los valores de cada input con trim() para limpiar espacios
        // esto evita guardar campos vacíos o con espacios extras, que pueden causar validaciones incorrectas
        let cedula = document.getElementById("cedula").value.trim();
        let nombre = document.getElementById("nombre").value.trim();
        let email = document.getElementById("email").value.trim();
        let contrasena = document.getElementById("contrasena").value.trim();
        let fecha = document.getElementById("fecha").value.trim();
        let usuario = document.getElementById("usuario").value.trim();

        // Se valida que ningún campo quede vacío
        if (!cedula || !nombre || !email || !contrasena || !fecha || !usuario) {
            alert("Por favor, complete todos los campos.");
            return;
        }

        // Se agrega el nuevo usuario al arreglo y se guarda en localStorage
        registros.push({ cedula, nombre, email, contrasena, fecha, usuario});
        localStorage.setItem("registros", JSON.stringify(registros));

        // Se actualiza la vista de usuarios registrados
        mostrarRegistros();

        // Se limpia el formulario después de registrar
        this.reset();
    });
}

// Se valida el inicio de sesión con los usuarios guardados en localStorage
const loginForm = document.getElementById("loginForm");

if (loginForm) {
    // Se captura el submit del formulario de login
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();

        // Se toman los datos del DNI y la contraseña del login

        let dniLogin = document.getElementById("dniLogin").value.trim();
        let passwordLogin = document.getElementById("passwordLogin").value.trim();

        // Se valida que ambos campos fueron ingresados

        if (!dniLogin || !passwordLogin) {
            alert("Por favor ingrese su DNI y contraseña.");
            return; 
        }

        // Se busca si existe un usuario con el mismo DNI y la misma contraseña}
        const usuarioEncontrado = registros.find(function(registro) {
            return registro.cedula === dniLogin && registro.contrasena === passwordLogin;
        });

        // Si el usuario existe, se guarda el usuario actual y se redirige al home
        // esto permite reconocer al usuario en la siguiente página y darle acceso al sistema
        if (usuarioEncontrado) {
            localStorage.setItem("usuarioActual", JSON.stringify(usuarioEncontrado));
            window.location.href = "home.html";
        } else {
            //Si no coincide, salta un mensaje informando al usuario.
            alert("DNI o contraseña incorrectos.");
        }
    });
}

// Se muestra la lista de registros al cargar la página solo si existe el contenedor..
mostrarRegistros();

// Se prepara la visualización del usuario actual en la home.
function mostrarDatosUsuario() {
    const usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));
    const contenedor = document.getElementById("datosUsuario");

    if (!usuarioActual || !contenedor) return;

    document.getElementById("usuarioDni").textContent = usuarioActual.cedula;
    document.getElementById("usuarioNombre").textContent = usuarioActual.nombre;
    document.getElementById("usuarioEmail").textContent = usuarioActual.email;
    document.getElementById("usuarioFecha").textContent = usuarioActual.fecha;
    document.getElementById("usuario").textContent = usuarioActual.usuario;
    
}

if (document.getElementById("datosUsuario")) {
    mostrarDatosUsuario();
}